
<div class="header">
            
            <h1 class="page-title"><?php echo $this->lang->line('license'); ?></h1>
</div>
        


<div class="container-fluid">
<div class="row-fluid">    

    <div class="http-error">
        <h1><?php echo $this->lang->line('license_error'); ?></h1>
        <p class="info"><?php echo $this->lang->line('you_need_buy_license'); ?></p>
        <p><i class="icon-home"></i></p>
        <p><a href="http://www.lepus.cc" target="blank"><?php echo $this->lang->line('buy_license'); ?></a></p>
    </div>


