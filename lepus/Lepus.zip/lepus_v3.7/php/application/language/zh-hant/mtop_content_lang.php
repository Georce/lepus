<?php

$lang['db_servers'] = 'DB Servers';
$lang['application'] = 'Application';
$lang['servers'] = 'Servers';
$lang['host'] = 'Host';
$lang['ip_address'] = 'IP Address';
$lang['db_role'] = 'Role';
$lang['master'] = 'Master';
$lang['slave'] = 'Slave';
$lang['delay'] = 'Delay';
$lang['connected'] = 'Connected';
$lang['running'] = 'Running';
$lang['uptime'] = 'Uptime';
$lang['qps'] = 'QPS';
$lang['tps'] = 'TPS';

$lang['the_latest_acquisition_time']='The latest acquisition time';
$lang['the_monitoring_process_is_not_started']='The monitoring process is not started or abnormal';


/* End of file mtop_content_lang.php */
/* Location: ./system/language/zh-hant/mtop_content_lang.php */